# Catatan Submission

Untuk menjalankan project ini saya hanya menggunakan NGINX
```
